package day2;

public class Salarycalculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
