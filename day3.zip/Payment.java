package day2;

interface Payments{
	void makepayments(double amount);
}
class Upipayments implements Payments{
	@Override
	public
	void makepayments(double amount) {
		System.out.println("upl payment:rs."+amount);
	}
}
class Cardpayment implements Payments{
	@Override
	public
	void makepayments(double amount) {
		System.out.println("card payment succesfull:rs"+amount);
	}
}

public class Payment {

	public static void main(String[] args) {
     Upipayments upi=new Upipayments();
     Cardpayment card = new Cardpayment();
     upi.makepayments(50000);
     card.makepayments(25000);
	}

}
