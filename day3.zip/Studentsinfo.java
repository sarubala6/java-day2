package day2;

public class Studentsinfo {

	
	public static void main(String[] args) {
		if(args.length<4) {
			System.out.println("Usage: java Students info<rollno><name><department><mark>");
			return;
		}
		System.out.println("Roll no:"+args[0]);
		System.out.println("Name:"+args[1]);
		System.out.println("Department:"+args[2]);
		System.out.println("Mark:"+args[3]);

	}

}
