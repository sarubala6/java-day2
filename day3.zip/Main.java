package day2;
interface Collage{
	String collagename ="KCE";
	static void displaycollage() {
		System.out.println("collagename:"+collagename);
	}
}
class Student implements Collage{
    int rollno =202;
    String name ="saru";
    void displayStudent() {
    	System.out.println("roll no:"+rollno);
    	System.out.println("name:"+name);
    }
}
public class Main {

	public static void main(String[] args) {
		Collage.displaycollage();
		Student s = new Student();
		s.displayStudent();

	}

}
