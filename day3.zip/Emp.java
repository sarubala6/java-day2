package day2;

class Employee {
    int employeeid;
    String employeename;
    double salary;

    Employee(int employeeid, String employeename, double salary) {
        this.employeeid = employeeid;
        this.employeename = employeename;
        this.salary = salary;
    }
}

public class Emp {

    public static void main(String[] args) {
        Employee[] emp = new Employee[5];

        emp[0] = new Employee(101, "arul", 25000);
        emp[1] = new Employee(102, "kavi", 26000);
        emp[2] = new Employee(103, "ravi", 77000);
        emp[3] = new Employee(104, "priya", 28000);
        emp[4] = new Employee(105, "Anu", 50000);

        System.out.println("Employees with salary greater than 30000:");

        for (int i = 0; i < emp.length; i++) {
            if (emp[i].salary > 30000) {
                System.out.println("ID: " + emp[i].employeeid);
                System.out.println("Name: " + emp[i].employeename);
                System.out.println("Salary: " + emp[i].salary);
                System.out.println();
            }
        }
    }
}