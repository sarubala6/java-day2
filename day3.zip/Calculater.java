package day2;

public class Calculater {
	void add(int a, int b) {
		System.out.println("Sum of two integer:"+(a+b));
	}
	void add(int a, int b, int c) {
		System.out.println("Sum of three integer:"+(a+b+c));
	}
	void add(double a,double b) {
		System.out.println("Sum of two double:"+(a+b));
	}

	public static void main(String[] args) {
	Calculater c = new Calculater();
	c.add(20,30);
	c.add(30,70,55);
	c.add(80.1,22.9);

	}

}
