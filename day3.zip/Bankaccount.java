package day2;

abstract class Bankaccount {

    abstract void calculatedinterast();

    void displayBankname() {
        System.out.println("Bank Name: SBI");
    }
}

class SavingAccount extends Bankaccount {
    @Override
    void calculatedinterast() {
        System.out.println("Saving Account Interest: 5%");
    }
}

class CurrentAccount extends Bankaccount {
    @Override
    void calculatedinterast() {
        System.out.println("Current Account Interest: 3%");
    }


    public static void main(String[] args) {

        SavingAccount s = new SavingAccount();
        CurrentAccount c = new CurrentAccount();

        s.displayBankname();
        s.calculatedinterast();

        c.displayBankname();
        c.calculatedinterast();
    }
}