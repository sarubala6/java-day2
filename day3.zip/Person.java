package day2;
class Persons{
	String name;
	int age;

 Persons(String name, int age){
	 this.name= name;
	 this.age= age;
 }
}
class Students extends Persons{
	int rollno;
	String department;
	Students (String name,int age, int rollno,String department){
		super(name,age);
		this.rollno= rollno;
		this.department=department;
	}
void display() {
	System.out.println("name:"+name);
	System.out.println("age:"+age);
	System.out.println("rollno:"+rollno);
	System.out.println("dapartment:"+department);
}
}

public class Person {
   
	public static void main(String[] args) {
	   
        Students s =new Students("arul",20,101,"cse");
        s.display();
	}

}
